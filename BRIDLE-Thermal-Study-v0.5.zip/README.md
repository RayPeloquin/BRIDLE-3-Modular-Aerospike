# BRIDLE thermal screening review v0.5

Open BRIDLE-Thermal-Lab-v0.5.html in a browser for the offline explorer.
Read BRIDLE-Thermal-Review-v0.5.md for definitions, exact solutions,
verified numbers and limitations. All quantities are dimensionless and
uncalibrated; no hardware performance has been measured.

Reproduce with Python and the versions in requirements.txt:

    python thermal_model.py
    python build_review.py

The first command verifies consistency and writes results/model-results.json,
results/reserve-curves.csv and results/BRIDLE-Reserve-Comparison.png.
The second writes the reviewed note and this package. qa_browser.cjs
optionally checks the HTML with Playwright; it is not a runtime dependency
of the explorer. Browser rendering was not available during this review.
The actual JS and control behavior passed qa_js_model.cjs in a minimal
DOM harness; run it with a modern Node.js as: node qa_js_model.cjs.
Source reports are superseded for this reviewed model.
