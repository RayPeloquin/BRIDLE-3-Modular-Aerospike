/* Optional frontend validation; not a runtime dependency of the offline HTML. */
const fs=require("fs"),path=require("path");
const {chromium}=require(require.resolve("playwright",{paths:[process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES||__dirname]}));
async function main(){
  const root=__dirname;
  const reference=JSON.parse(fs.readFileSync(path.join(root,"results/model-results.json"),"utf8"));
  const browser=await chromium.launch({headless:true,args:["--no-sandbox"]});
  const page=await browser.newPage({viewport:{width:1360,height:1000}});
  const errors=[],external=[];
  page.on("pageerror",e=>errors.push(String(e)));
  await page.route("**/*",r=>{const u=r.request().url();if(u.startsWith("file:")||u.startsWith("data:")||u.startsWith("blob:"))r.continue();else{external.push(u);r.abort();}});
  await page.goto("file://"+path.join(root,"BRIDLE-Thermal-Lab-v0.5.html"));
  await page.waitForFunction(()=>!!window.bridleModel);
  const checks=[];
  for(const row of reference.local_cases){
    const p={shared:row.shared,main:row.main,reserve:row.reserve,sw:row.mode==="switch",low:row.mode==="high"?.4:.02,horizon:12};
    const got=await page.evaluate(p=>{const s=window.bridleModel.simulate(p);return {peak:s.peak,other:s.other,changes:s.changes};},p);
    if(Math.abs(got.peak-row.affected_peak)>.0005||Math.abs(got.other-row.other_peak)>.0005)throw Error("Frontend mismatch "+row.label+" "+JSON.stringify(got));
    checks.push({case:row.label,peak:got.peak,other:got.other,passed:true});
  }
  await page.locator('[data-preset="reserve"]').click();
  if((await page.locator("#peak-main").innerText())!=="1.205")throw Error("Default reserve UI result differs");
  await page.locator('[data-preset="window"]').click();
  if(!(await page.locator("#status").innerText()).includes("Within window"))throw Error("Window trap did not pass its finite window");
  if(!(await page.locator("#all-time").innerText()).includes("exceeds"))throw Error("Window trap did not flag late failure");
  await page.locator('[data-preset="shared"]').click();
  if(!(await page.locator("#status").innerText()).includes("exceeded"))throw Error("Shared fault not flagged");
  await page.locator('[data-preset="larger"]').click();
  if(!(await page.locator("#all-time").innerText()).includes("satisfies"))throw Error("Larger reserve all-time condition differs");
  await page.locator('[data-preset="shared"]').click();
  const downloadPromise=page.waitForEvent("download");
  await page.locator("#export").click();
  const download=await downloadPromise;
  const csv=fs.readFileSync(await download.path(),"utf8");
  if(!csv.includes("theta_5")||csv.split("\n").length<1000)throw Error("CSV export invalid");
  const qa=path.join(root,"..","tmp","bridle-qa-v05");fs.mkdirSync(qa,{recursive:true});
  await page.screenshot({path:path.join(qa,"desktop.png"),fullPage:true});
  await page.setViewportSize({width:390,height:844});
  const overflow=await page.evaluate(()=>({body:document.body.scrollWidth,view:window.innerWidth}));
  if(overflow.body>overflow.view+1)throw Error("Mobile horizontal overflow "+JSON.stringify(overflow));
  await page.screenshot({path:path.join(qa,"mobile.png"),fullPage:true});
  if(errors.length||external.length)throw Error(JSON.stringify({errors,external}));
  const result={checks:checks,ui:["Presets update computed statistics","Finite-window trap flags its all-time failure","Shared fault flagged","Larger reserve all-time check","CSV export","390px layout without horizontal overflow","No page errors or external requests"],screenshots:qa};
  fs.writeFileSync(path.join(root,"results/browser-checks.json"),JSON.stringify({checks:checks,ui:result.ui},null,2));
  console.log(JSON.stringify(result,null,2));
  await browser.close();
}
main().catch(e=>{console.error(e);process.exit(1);});
